<script src="<?php echo base_url();?>assets/js/vendor.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/scripts.min.js"></script>
    <!-- Customizer scripts-->
    <script src="<?php echo base_url();?>assets/customizer/customizer.min.js"></script>