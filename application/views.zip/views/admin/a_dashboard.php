<?php $this->load->view('admin/template/head'); ?>
<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/aside'); ?>

<div class="content-wrapper">
  	<section class="content">
  		<div class="row">
  			
	        
	        
        </div>
  </section>
  </div>
	
<?php $this->load->view('admin/template/foot'); ?>
<?php $this->load->view('admin/template/js'); ?>